#include <iostream>
#include "Cmaterial.h"
#include "CSystem.h"

int main()
{
    srand((unsigned int)time(NULL));
    CSystem c1;
    c1.init();
}
